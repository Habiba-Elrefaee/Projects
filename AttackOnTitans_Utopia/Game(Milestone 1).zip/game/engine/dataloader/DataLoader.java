package game.engine.dataloader;
import game.engine.titans.TitanRegistry;
import game.engine.weapons.WeaponRegistry;

import java.io.*;  
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class DataLoader {
	 private static final String TITANS_FILE_NAME = "titans.csv";
	private static final String WEAPONS_FILE_NAME= "weapons.csv";
	public String getTITANS_FILE_NAME() {
		return TITANS_FILE_NAME;
	}
	public String getWEAPONS_FILE_NAME() {
		return WEAPONS_FILE_NAME;
	}

    public static HashMap<Integer,TitanRegistry>readTitanRegistry() throws IOException {
     HashMap<Integer,TitanRegistry> hmap=new HashMap<Integer,TitanRegistry>();
    
    BufferedReader br=new BufferedReader(new FileReader(TITANS_FILE_NAME));
    String d;
    int code;
	int baseHealth;
	int baseDamage;
	int heightInMetres;
	int speed;
	int resourcesValue;
	int dangerLevel;
    while((d=br.readLine())!=null)
    {
    	String[]res=d.split(",");
    	 code=Integer.parseInt(res[0]);
    	 baseHealth=Integer.parseInt(res[1]);
    	 baseDamage=Integer.parseInt(res[2]);
    	 heightInMetres=Integer.parseInt(res[3]);
    	 speed=Integer.parseInt(res[4]);
    	 resourcesValue=Integer.parseInt(res[5]);
    	 dangerLevel=Integer.parseInt(res[6]);
    	 TitanRegistry tr=new TitanRegistry(code,baseHealth,baseDamage,heightInMetres,speed,resourcesValue,dangerLevel);
    	  hmap.put(code,tr);
    	  
    }
   // TitanRegistry tr=new TitanRegistry(code,baseHealth,baseDamage,heightInMetres,speed,resourcesValue,resourcesValue);
   // hmap.put(code,tr);
    return hmap;
    }
    public static HashMap<Integer,WeaponRegistry>readWeaponRegistry() throws IOException{
    	
    	 HashMap<Integer,WeaponRegistry> hmap2=new HashMap<Integer,WeaponRegistry>();
    	 WeaponRegistry wr;
    	 BufferedReader breader=new BufferedReader(new FileReader(WEAPONS_FILE_NAME));
    	 String g;
    	 while((g=breader.readLine())!=null)
    	 {
    		 String[]res=g.split(",");
    		 
    		 int code=Integer.parseInt(res[0]);
    		 int price=Integer.parseInt(res[1]);
    		 int damage=Integer.parseInt(res[2]);
    		 String name=res[3];
    		 
    		 if (res.length==4)
    			  wr=new WeaponRegistry(code, price, damage, name); 
    		 else if (res.length==6){
    			 int minRange=Integer.parseInt(res[4]);
    		 	 int maxRange=Integer.parseInt(res[5]);
    		 	wr=new WeaponRegistry(code, price, damage, name, minRange, maxRange);
    		 }
    		 else {
    			 wr=new WeaponRegistry(code, price);
    		 }
    		 hmap2.put(wr.getCode(),wr);
    	 }
    	 //WeaponRegistry wr=new WeaponRegistry(wr.getCode(),wr.getDamage(),wr.getPrice(),wr.getName(),wr.getMinRange(),wr.getMaxRange());
    	 
    	 return hmap2;
}
}

package game.engine.interfaces;
public interface Attackee {
	 int getCurrentHealth();
	 void setCurrentHealth(int health);
	 int getResourcesValue();
}

package game.engine.interfaces;

public interface Attacker {
	int getDamage();
}

package game.engine.weapons;

public class SniperCannon extends Weapon{
	public final static int WEAPON_CODE = 2;
	public SniperCannon(int baseDamage) {
		super(baseDamage);
	}
	
}

package game.engine.weapons;

public class WallTrap extends Weapon{
	public final static int WEAPON_CODE = 4;
	public WallTrap(int baseDamage) {
		super(baseDamage);
	}
	
}
